// @author G. Hemingway, copyright 2017
//
#include "Universe.h"
#include "Object.h"

Universe* Universe::inst = nullptr;

/**
 *  Returns the only instance of the Universe
 */
Universe* Universe::instance()
{
    if (!inst)
        inst = new Universe();
    return inst;
}

/**
 *  Releases all the dynamic objects still registered with the Universe.
 */
Universe::~Universe()
{
    release(objects);
    inst = nullptr;
}

/**
 *  Registers an Object with the universe. The Universe will clean up this
 *  object when it deems necessary.
 */
Object* Universe::addObject(Object* ptr)
{
    objects.push_back(ptr);
    return ptr;
}

/**
 *  Returns the begin iterator to the actual Objects. The order of itetarion
 *  will be the same as that over getSnapshot()'s result as long as no new
 *  objects are added to either of the containers.
 */
Universe::iterator Universe::begin()
{
    return objects.begin();
}

/**
 *  Returns the begin iterator to the actual Objects. The order of itetarion
 *  will be the same as that over getSnapshot()'s result as long as no new
 *  objects are added to either of the containers.
 */
Universe::const_iterator Universe::begin() const
{
    return objects.begin();
}

/**
 *  Returns the end iterator to the actual Objects. The order of itetarion
 *  will be the same as that over getSnapshot()'s result as long as no new
 *  objects are added to either of the containers.
 */
Universe::iterator Universe::end()
{
    return objects.end();
}

/**
 *  Returns the end iterator to the actual Objects. The order of itetarion
 *  will be the same as that over getSnapshot()'s result as long as no new
 *  objects are added to either of the containers.
 */
Universe::const_iterator Universe::end() const
{
    return objects.end();
}

/**
 *  Returns a container of copies of all the Objects registered with the
 *  Universe. This should be used as the source of data for computing the
 *  next step in the simulation
 */
std::vector<Object*> Universe::getSnapshot() const
{
    std::vector<Object*> copy(objects.size(), nullptr);
    for (size_t i = 0; i < objects.size(); ++i)
        copy[i] = objects[i]->clone();
    return copy;
}

/**
 *  Advances the simulation by the provided time step. For this assignment,
 *  you must assume that the first registered object is a "sun" and its
 *  position should not be affected by any of the other objects.
 */
void Universe::stepSimulation(const double& timeSec)
{
    std::vector<Object*> copy = getSnapshot();
    for (size_t obj1 = 1; obj1 < objects.size(); ++obj1) {

        vector2 force;
        for (size_t obj2 = 0; obj2 < objects.size(); ++obj2) {
            if (obj1 != obj2)
                force += objects[obj1]->getForce(*objects[obj2]);
        }

        vector2 accel = force / objects[obj1]->getMass();
        vector2 old_pos = objects[obj1]->getPosition();
        vector2 old_vel = objects[obj1]->getVelocity();
        vector2 new_pos = old_pos + old_vel * timeSec;
        vector2 new_vel = old_vel + accel * timeSec;

        copy[obj1]->setVelocity(new_vel);
        copy[obj1]->setPosition(new_pos);
    }
    swap(copy);
}

/**
 *  Swaps the contents of the provided container with the Universe's Object
 *  store and releases the old Objects.
 */
void Universe::swap(std::vector<Object*>& snapshot)
{
    objects.swap(snapshot);
    release(snapshot);
}

/**
 *  Private constructor. Ensures access control.
 */
Universe::Universe()
    : objects()
{
}

/**
 *  Calls delete on each pointer and removes it from the container.
 */
void Universe::release(std::vector<Object*>& objects)
{
    for (Object* obj : objects)
        delete obj;
    objects.clear();
}

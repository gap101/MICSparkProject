// @author G. Hemingway, copyright 2017
//
#include "ObjectFactory.h"
#include "Object.h"
#include "Universe.h"

/**
 *  Creates an object with the provided parameters. Default values of zero
 *  will be assigned to everything except for name.
 */
Object* ObjectFactory::makeObject(
    std::string name, double mass, const vector2& pos, const vector2& vel)
{
    auto obj = new Object(name, mass, pos, vel);
    Universe::instance()->addObject(obj);
    return obj;
}

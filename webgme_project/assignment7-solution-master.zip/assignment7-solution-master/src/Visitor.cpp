// @author G. Hemingway, copyright 2017
//
#include "Visitor.h"
#include "Object.h"

/**
 *  Construct a visitor that prints to the provided ostream.
 */
PrintVisitor::PrintVisitor(std::ostream& os)
    : os(os)
{
}

/**
 *  Prints the object's name.
 */
void PrintVisitor::visit(Object& object)
{
    os << object.getName();
}
